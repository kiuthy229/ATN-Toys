<?php
$server="localhost";
$username="postgres";
$password="123456";
$database="test";
$connString="host=$server dbname=$database user=$username password=$password";
?>